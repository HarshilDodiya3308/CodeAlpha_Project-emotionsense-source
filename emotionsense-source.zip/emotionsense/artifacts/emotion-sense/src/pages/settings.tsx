import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/lib/auth";
import { User, Shield, Bell, Palette } from "lucide-react";
import { useTheme } from "@/components/theme-provider";

export default function Settings() {
  const { user } = useAuth();
  const { theme, setTheme } = useTheme();

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-4xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">System Configuration</h1>
        <p className="text-muted-foreground">Manage your analyst profile and platform preferences</p>
      </div>

      <div className="grid gap-6">
        <Card className="border-border/50 bg-card/50 backdrop-blur">
          <CardHeader>
            <div className="flex items-center gap-2">
              <User className="h-5 w-5 text-primary" />
              <CardTitle>Profile Details</CardTitle>
            </div>
            <CardDescription>Update your personal information and credentials</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" defaultValue={user?.name || ""} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" type="email" defaultValue={user?.email || ""} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="role">Access Role</Label>
                <Input id="role" defaultValue={user?.role || "analyst"} disabled className="bg-muted" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="org">Organization</Label>
                <Input id="org" defaultValue="Replit Intelligence" disabled className="bg-muted" />
              </div>
            </div>
            <div className="flex justify-end pt-4">
              <Button>Save Profile Changes</Button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50 backdrop-blur">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-primary" />
              <CardTitle>Appearance</CardTitle>
            </div>
            <CardDescription>Customize the interface telemetry and visual theme</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Theme Preference</Label>
                <p className="text-sm text-muted-foreground">Select the application color mode</p>
              </div>
              <Select value={theme} onValueChange={(val: any) => setTheme(val)}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select theme" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">Light Mode</SelectItem>
                  <SelectItem value="dark">Dark Mode (Midnight)</SelectItem>
                  <SelectItem value="system">System Default</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center justify-between border-t border-border/50 pt-6">
              <div className="space-y-0.5">
                <Label>High Contrast Data</Label>
                <p className="text-sm text-muted-foreground">Use maximum contrast for visualization charts</p>
              </div>
              <Switch defaultChecked />
            </div>
            
            <div className="flex items-center justify-between border-t border-border/50 pt-6">
              <div className="space-y-0.5">
                <Label>Hardware Acceleration</Label>
                <p className="text-sm text-muted-foreground">Enable WebGL for signal waveforms</p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50 backdrop-blur">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <CardTitle>Data Privacy & Security</CardTitle>
            </div>
            <CardDescription>Manage how audio telemetry is processed and stored</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Store Audio Artifacts</Label>
                <p className="text-sm text-muted-foreground">Retain raw audio files after analysis</p>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between border-t border-border/50 pt-6">
              <div className="space-y-0.5">
                <Label>Allow Model Training</Label>
                <p className="text-sm text-muted-foreground">Opt-in to use anonymized data to improve the CNN-LSTM model</p>
              </div>
              <Switch />
            </div>
            <div className="pt-6 border-t border-border/50">
              <Button variant="destructive" className="w-full sm:w-auto">Purge Analytics History</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
