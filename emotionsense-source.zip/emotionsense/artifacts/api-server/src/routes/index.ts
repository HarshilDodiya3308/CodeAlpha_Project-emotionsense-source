import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import analysisRouter from "./analysis";
import historyRouter from "./history";
import analyticsRouter from "./analytics";
import audioRouter from "./audio";
import modelsRouter from "./models";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(analysisRouter);
router.use(historyRouter);
router.use(analyticsRouter);
router.use(audioRouter);
router.use(modelsRouter);

export default router;
