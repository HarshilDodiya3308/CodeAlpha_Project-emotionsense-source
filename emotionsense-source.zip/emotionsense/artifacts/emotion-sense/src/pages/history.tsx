import { useState } from "react";
import { useListHistory } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search, Filter, Calendar as CalendarIcon, ChevronLeft, ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

const EMOTION_COLORS: Record<string, string> = {
  happy: "var(--emotion-happy)",
  sad: "var(--emotion-sad)",
  angry: "var(--emotion-angry)",
  fear: "var(--emotion-fear)",
  neutral: "var(--emotion-neutral)",
  calm: "var(--emotion-calm)",
  surprise: "var(--emotion-surprise)",
  disgust: "var(--emotion-disgust)",
};

export default function History() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [emotionFilter, setEmotionFilter] = useState("all");
  
  const { data, isLoading } = useListHistory({
    page,
    limit: 10,
    search: search || undefined,
    emotion: emotionFilter !== 'all' ? emotionFilter : undefined
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Telemetry Log</h1>
        <p className="text-muted-foreground">Historical ledger of analyzed audio signals</p>
      </div>

      <Card className="border-border/50 bg-card/50 backdrop-blur">
        <CardHeader className="pb-4 border-b border-border/50">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by filename or insight..." 
                className="pl-9 bg-background/50"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            
            <div className="flex items-center gap-2 w-full md:w-auto">
              <Select value={emotionFilter} onValueChange={setEmotionFilter}>
                <SelectTrigger className="w-full md:w-[180px] bg-background/50">
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    <span><SelectValue placeholder="All Emotions" /></span>
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Vectors</SelectItem>
                  {Object.keys(EMOTION_COLORS).map(emotion => (
                    <SelectItem key={emotion} value={emotion} className="capitalize">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: EMOTION_COLORS[emotion] }}></div>
                        {emotion}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="rounded-md">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/20 hover:bg-muted/20">
                  <TableHead>Signal Source</TableHead>
                  <TableHead>Primary Vector</TableHead>
                  <TableHead>Confidence</TableHead>
                  <TableHead className="hidden md:table-cell">Semantic Insight</TableHead>
                  <TableHead className="text-right">Timestamp</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array(5).fill(0).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-6 w-20 rounded-full" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-12" /></TableCell>
                      <TableCell className="hidden md:table-cell"><Skeleton className="h-5 w-48" /></TableCell>
                      <TableCell className="text-right"><Skeleton className="h-5 w-24 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : data?.items.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                      No telemetry data found matching your parameters.
                    </TableCell>
                  </TableRow>
                ) : (
                  data?.items.map((item) => (
                    <TableRow key={item.id} className="group hover:bg-muted/10 transition-colors">
                      <TableCell className="font-medium text-sm max-w-[200px] truncate" title={item.filename}>
                        {item.filename}
                        {item.duration && (
                          <div className="text-xs text-muted-foreground font-mono mt-1">
                            {format(new Date(item.duration * 1000), 'mm:ss')}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className="capitalize font-mono text-[10px] px-2 py-0.5 tracking-wider"
                          style={{ 
                            color: EMOTION_COLORS[item.dominantEmotion],
                            borderColor: EMOTION_COLORS[item.dominantEmotion],
                            backgroundColor: `${EMOTION_COLORS[item.dominantEmotion]}15`
                          }}
                        >
                          {item.dominantEmotion}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {item.confidence.toFixed(1)}%
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-xs text-muted-foreground max-w-md truncate" title={item.aiInsight || ''}>
                        {item.aiInsight || '-'}
                      </TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground font-mono">
                        {format(new Date(item.createdAt), 'MMM dd, HH:mm')}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          
          {data && data.total > 0 && (
            <div className="flex items-center justify-between p-4 border-t border-border/50">
              <div className="text-xs text-muted-foreground font-mono">
                Showing {(page - 1) * 10 + 1} - {Math.min(page * 10, data.total)} of {data.total}
              </div>
              <div className="flex gap-1">
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="h-8 w-8" 
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="h-8 w-8"
                  onClick={() => setPage(p => p + 1)}
                  disabled={page * 10 >= data.total}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
