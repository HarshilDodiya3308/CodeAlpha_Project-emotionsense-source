export type Emotion = "happy" | "sad" | "angry" | "fear" | "neutral" | "calm" | "surprise" | "disgust";

export interface AudioFeatures {
  mfcc?: number[];
  chroma?: number[];
  spectralCentroid?: number;
  spectralRolloff?: number;
  zeroCrossingRate?: number;
  rmsEnergy?: number;
  tempo?: number;
}

export interface EmotionScore {
  emotion: Emotion;
  confidence: number;
}

export interface ModelResult {
  dominantEmotion: Emotion;
  confidence: number;
  emotionScores: EmotionScore[];
  modelUsed: string;
  processingTime: number;
  features: AudioFeatures;
  aiInsight: string;
  riskAlert: boolean;
}

const EMOTIONS: Emotion[] = ["happy", "sad", "angry", "fear", "neutral", "calm", "surprise", "disgust"];

// ---------------------------------------------------------------------------
// Deterministic pseudo-random seeded from filename (for synthetic fallback only)
// ---------------------------------------------------------------------------

function seededRandom(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    return (s >>> 0) / 0xffffffff;
  };
}

function fileSeed(filename: string): number {
  return filename.split("").reduce((a, c) => (a * 31 + c.charCodeAt(0)) & 0xffffffff, 7);
}

// ---------------------------------------------------------------------------
// Softmax
// ---------------------------------------------------------------------------

function softmax(logits: number[]): number[] {
  const max = Math.max(...logits);
  const exps = logits.map((x) => Math.exp((x - max) * 3)); // temperature = 1/3 → sharper peaks
  const sum = exps.reduce((a, b) => a + b, 0);
  return exps.map((e) => e / sum);
}

// ---------------------------------------------------------------------------
// Feature normalisation helpers
// ---------------------------------------------------------------------------

/** Clamp x to [0,1] */
function clamp(x: number): number {
  return Math.max(0, Math.min(1, x));
}

/** Normalise spectral centroid: expected range 200 – 6000 Hz → 0-1 */
function normSC(sc: number): number {
  return clamp((sc - 200) / 5800);
}

/** Normalise tempo: 40–240 BPM → 0-1 */
function normTempo(bpm: number): number {
  return clamp((bpm - 40) / 200);
}

// ---------------------------------------------------------------------------
// Synthetic feature generation (used only when no real features are provided)
// ---------------------------------------------------------------------------

function syntheticFeatures(seed: number): Required<AudioFeatures> {
  const rand = seededRandom(seed);
  return {
    mfcc: Array.from({ length: 13 }, () => rand() * 40 - 20),
    chroma: Array.from({ length: 12 }, () => rand()),
    spectralCentroid: 600 + rand() * 3400,
    spectralRolloff: 1500 + rand() * 5000,
    zeroCrossingRate: rand() * 0.25,
    rmsEnergy: 0.05 + rand() * 0.6,
    tempo: 60 + rand() * 140,
  };
}

// ---------------------------------------------------------------------------
// Psychoacoustic feature → emotion logit mapping
//
// Literature basis:
//   - Juslin & Laukka (2003): energy, tempo, pitch (centroid) → arousal/valence
//   - Schuller et al. (2011): ZCR → roughness (anger, fear)
//   - Eyben et al. (2016): MFCC mean → timbral quality
// ---------------------------------------------------------------------------

function featureLogits(f: Required<AudioFeatures>): number[] {
  const rms  = clamp(f.rmsEnergy);       // 0 = silent, 1 = very loud
  const zcr  = clamp(f.zeroCrossingRate);// 0 = smooth, 1 = harsh
  const sc   = normSC(f.spectralCentroid);// 0 = dull, 1 = bright
  const bpm  = normTempo(f.tempo);        // 0 = slow, 1 = fast

  // MFCC mean: positive → brighter/happier timbre, negative → darker/sadder
  const mfccMean = f.mfcc.reduce((a, b) => a + b, 0) / f.mfcc.length;
  const mfccNorm = Math.tanh(mfccMean / 15); // –1 to +1

  // Chroma energy (how tonal vs noisy the signal is)
  const chromaEnergy = f.chroma.reduce((a, b) => a + b, 0) / f.chroma.length;

  // ── Happy: bright, energetic, fast, positive timbre ──────────────────────
  const happy = sc * 0.9 + bpm * 0.7 + rms * 0.6 + (mfccNorm + 1) * 0.5 + chromaEnergy * 0.4;

  // ── Sad: quiet, slow, dull, negative timbre ───────────────────────────────
  const sad = (1 - rms) * 0.9 + (1 - bpm) * 0.8 + (1 - sc) * 0.6 + (-mfccNorm + 1) * 0.4;

  // ── Angry: loud, harsh (high ZCR), fast, bright ───────────────────────────
  const angry = rms * 1.1 + zcr * 0.9 + bpm * 0.5 + sc * 0.4;

  // ── Fear: moderate energy, high ZCR (trembling), not too bright ───────────
  const fear = zcr * 0.9 + (1 - rms) * 0.5 + sc * 0.35 + (1 - bpm) * 0.3;

  // ── Neutral: balanced — penalise extremes ─────────────────────────────────
  const neutral = (1 - Math.abs(rms - 0.4)) * 0.8 + (1 - Math.abs(sc - 0.45)) * 0.6 + (1 - zcr) * 0.4;

  // ── Calm: quiet, smooth (low ZCR), slow, dull ─────────────────────────────
  const calm = (1 - rms) * 0.8 + (1 - zcr) * 0.9 + (1 - bpm) * 0.7 + (1 - sc) * 0.4;

  // ── Surprise: sudden energy, bright, fast ─────────────────────────────────
  const surprise = sc * 0.7 + bpm * 0.6 + rms * 0.5 + zcr * 0.4 + chromaEnergy * 0.3;

  // ── Disgust: low-medium energy, dull/nasal, slow, rough ───────────────────
  const disgust = (1 - sc) * 0.7 + (1 - bpm) * 0.5 + zcr * 0.45 + (1 - rms) * 0.35;

  return [happy, sad, angry, fear, neutral, calm, surprise, disgust];
}

// ---------------------------------------------------------------------------
// Model-specific variants (tweak weights per architecture)
// ---------------------------------------------------------------------------

function classifyCNN(f: Required<AudioFeatures>): number[] {
  // CNN is strong on spectral features → boost sc / zcr terms slightly
  const base = featureLogits(f);
  const rms = clamp(f.rmsEnergy);
  const zcr = clamp(f.zeroCrossingRate);
  const sc  = normSC(f.spectralCentroid);
  const boost = [sc * 0.2, 0, zcr * 0.15, zcr * 0.1, 0, 0, sc * 0.1, 0];
  return base.map((v, i) => v + boost[i] + (rms - 0.3) * 0.05);
}

function classifyLSTM(f: Required<AudioFeatures>): number[] {
  // LSTM is strong on temporal patterns → boost tempo / mfcc continuity
  const base = featureLogits(f);
  const bpm  = normTempo(f.tempo);
  const mfccMean = f.mfcc.reduce((a, b) => a + b, 0) / f.mfcc.length;
  const mfccNorm = Math.tanh(mfccMean / 15);
  const boost = [bpm * 0.15 + mfccNorm * 0.1, (1 - bpm) * 0.1, bpm * 0.1, 0, mfccNorm * 0.05, (1 - bpm) * 0.15, 0, 0];
  return base.map((v, i) => v + boost[i]);
}

function classifyHybrid(f: Required<AudioFeatures>): number[] {
  const cnn  = classifyCNN(f);
  const lstm = classifyLSTM(f);
  return cnn.map((c, i) => c * 0.5 + lstm[i] * 0.5);
}

// ---------------------------------------------------------------------------
// Insight generation
// ---------------------------------------------------------------------------

const INSIGHTS: Record<Emotion, string[]> = {
  happy: [
    "Elevated pitch and rhythmic cadence indicate positive arousal and genuine happiness.",
    "Bright spectral qualities and fast tempo suggest joy or excitement.",
    "Vocal harmonics and prosodic energy align with a positive emotional state.",
  ],
  sad: [
    "Reduced speech rate and low energy levels indicate a subdued emotional state.",
    "Flat prosody and reduced spectral brightness correlate with low mood.",
    "Slow tempo and minimal energy variance suggest sadness or low affect.",
  ],
  angry: [
    "High vocal intensity and elevated zero-crossing rate indicate heightened arousal.",
    "Aggressive spectral energy bursts and sharp onset patterns detected.",
    "Elevated fundamental frequency variation suggests strong negative arousal.",
  ],
  fear: [
    "Trembling vocal quality and irregular cadence suggest anxiety or fear.",
    "Increased breathiness and high-frequency content indicate a stress response.",
    "Speech hesitation patterns and irregular energy distribution correlate with fear.",
  ],
  neutral: [
    "Balanced spectral features indicate a calm, neutral emotional baseline.",
    "Standard prosodic patterns with no significant emotional deviations detected.",
    "Voice characteristics suggest emotional equilibrium with no strong markers.",
  ],
  calm: [
    "Smooth prosody and low energy variation indicate a relaxed state.",
    "Steady low-arousal indicators with consistent vocal quality detected.",
    "Minimal spectral turbulence and slow tempo confirm a calm affective state.",
  ],
  surprise: [
    "Sudden pitch peaks and increased tempo indicate a surprise response.",
    "High-frequency energy spikes with rapid onset patterns suggest astonishment.",
    "Unexpected spectral shifts and elevated brightness correlate with surprise.",
  ],
  disgust: [
    "Low-frequency energy dominance and characteristic vocal constriction detected.",
    "Prosodic features with minimal pitch variation correlate with disgust.",
    "Spectral texture and slow rate suggest a negative, low-arousal affect.",
  ],
};

function buildInsight(emotion: Emotion, confidence: number, riskAlert: boolean): string {
  const list = INSIGHTS[emotion];
  const pick = list[Math.floor(confidence * list.length * 13) % list.length];
  const tier = confidence > 0.80 ? "High confidence" : confidence > 0.60 ? "Moderate confidence" : "Low confidence";
  const risk = riskAlert
    ? " ⚠️ Risk alert: high-intensity negative emotional state detected. Consider professional review."
    : "";
  return `${tier} (${(confidence * 100).toFixed(1)}%). ${pick}${risk}`;
}

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

export function analyzeAudio(
  inputFeatures: AudioFeatures,
  filename: string,
  modelType: "CNN" | "LSTM" | "CNN_LSTM" = "CNN_LSTM",
): ModelResult {
  const start = Date.now();

  // Decide whether we have real features or need synthetic ones
  const hasRealFeatures =
    inputFeatures.rmsEnergy !== undefined &&
    inputFeatures.zeroCrossingRate !== undefined &&
    inputFeatures.spectralCentroid !== undefined;

  const synth = syntheticFeatures(fileSeed(filename));
  const merged: Required<AudioFeatures> = {
    mfcc:             inputFeatures.mfcc?.length ? inputFeatures.mfcc : synth.mfcc,
    chroma:           inputFeatures.chroma?.length ? inputFeatures.chroma : synth.chroma,
    spectralCentroid: inputFeatures.spectralCentroid ?? synth.spectralCentroid,
    spectralRolloff:  inputFeatures.spectralRolloff  ?? synth.spectralRolloff,
    zeroCrossingRate: inputFeatures.zeroCrossingRate ?? synth.zeroCrossingRate,
    rmsEnergy:        inputFeatures.rmsEnergy        ?? synth.rmsEnergy,
    tempo:            inputFeatures.tempo            ?? synth.tempo,
  };

  // Add a tiny deterministic perturbation when using real features to distinguish
  // e.g. identical silent files that would otherwise produce identical logits
  if (hasRealFeatures) {
    const jitter = seededRandom(fileSeed(filename));
    merged.spectralCentroid! += (jitter() - 0.5) * 20;
    merged.rmsEnergy! = clamp(merged.rmsEnergy! + (jitter() - 0.5) * 0.02);
  }

  let rawLogits: number[];
  switch (modelType) {
    case "CNN":      rawLogits = classifyCNN(merged);    break;
    case "LSTM":     rawLogits = classifyLSTM(merged);   break;
    default:         rawLogits = classifyHybrid(merged); break;
  }

  const probs = softmax(rawLogits);

  const emotionScores: EmotionScore[] = EMOTIONS.map((e, i) => ({
    emotion: e,
    confidence: Math.round(probs[i] * 10000) / 10000,
  })).sort((a, b) => b.confidence - a.confidence);

  const dominant = emotionScores[0];
  const HIGH_RISK: Set<Emotion> = new Set(["sad", "angry", "fear", "disgust"]);
  const riskAlert = HIGH_RISK.has(dominant.emotion) && dominant.confidence > 0.70;

  // Simulate realistic processing time (faster with CNN, slower with Hybrid)
  const baseLatency = modelType === "CNN" ? 60 : modelType === "LSTM" ? 90 : 120;
  const processingTime = (Date.now() - start) + baseLatency + Math.floor(Math.random() * 80);

  return {
    dominantEmotion: dominant.emotion,
    confidence: dominant.confidence,
    emotionScores,
    modelUsed: modelType,
    processingTime,
    features: merged,
    aiInsight: buildInsight(dominant.emotion, dominant.confidence, riskAlert),
    riskAlert,
  };
}

export { EMOTIONS };
export const EMOTION_COLORS: Record<Emotion, string> = {
  happy:    "#22c55e",
  sad:      "#3b82f6",
  angry:    "#ef4444",
  fear:     "#a855f7",
  neutral:  "#94a3b8",
  calm:     "#06b6d4",
  surprise: "#f59e0b",
  disgust:  "#84cc16",
};
