import { pgTable, serial, text, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const audioFilesTable = pgTable("audio_files", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  filePath: text("file_path").notNull(),
  duration: real("duration").notNull().default(0),
  fileSize: integer("file_size").notNull(),
  format: text("format").notNull().default("wav"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAudioFileSchema = createInsertSchema(audioFilesTable).omit({ id: true, createdAt: true });
export type InsertAudioFile = z.infer<typeof insertAudioFileSchema>;
export type AudioFile = typeof audioFilesTable.$inferSelect;
