import { useGetMe, useGetAnalysisResult, useListHistory } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, Cpu, Database, Network } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Models() {
  // In a real app we'd use useListModels, but if it's not fully defined we can hardcode the standard 3
  const models = [
    {
      id: "cnn-base",
      name: "ConvNet Audio Baseline",
      type: "CNN",
      accuracy: 84.5,
      description: "Fast convolutional neural network operating on Mel-spectrograms. Low latency, ideal for real-time edge processing.",
      parameters: "2.4M",
      trainingDataset: "RAVDESS + SAVEE",
      isDefault: false
    },
    {
      id: "lstm-temporal",
      name: "Temporal LSTM Array",
      type: "LSTM",
      accuracy: 82.1,
      description: "Recurrent network focusing on temporal features like pitch contours and energy variations over time.",
      parameters: "1.8M",
      trainingDataset: "CREMA-D + RAVDESS",
      isDefault: false
    },
    {
      id: "hybrid-fusion-v2",
      name: "CNN-LSTM Hybrid Fusion V2",
      type: "CNN_LSTM",
      accuracy: 91.2,
      description: "State-of-the-art hybrid architecture extracting spatial features via CNN and temporal dependencies via LSTM. High precision.",
      parameters: "8.6M",
      trainingDataset: "RAVDESS + CREMA-D + SAVEE + TESS",
      isDefault: true
    }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Inference Models</h1>
        <p className="text-muted-foreground">Manage and compare active neural network architectures</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {models.map((model) => (
          <Card key={model.id} className={`border-border/50 bg-card/50 backdrop-blur relative overflow-hidden ${model.isDefault ? 'border-primary/50 shadow-md shadow-primary/10' : ''}`}>
            {model.isDefault && (
              <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-[10px] font-bold px-3 py-1 uppercase tracking-wider rounded-bl-lg">
                Active Default
              </div>
            )}
            <CardHeader className="pb-4">
              <div className="flex items-center gap-3 mb-2">
                <div className={`p-2 rounded-lg ${model.type === 'CNN_LSTM' ? 'bg-primary/20 text-primary' : 'bg-secondary text-muted-foreground'}`}>
                  {model.type === 'CNN' ? <Network className="h-5 w-5" /> : 
                   model.type === 'LSTM' ? <Cpu className="h-5 w-5" /> : 
                   <Brain className="h-5 w-5" />}
                </div>
                <div>
                  <Badge variant="outline" className="mb-1">{model.type}</Badge>
                  <CardTitle className="text-lg">{model.name}</CardTitle>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-6 min-h-[60px]">
                {model.description}
              </p>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-muted-foreground">Validation Accuracy</span>
                    <span className="font-bold text-primary">{model.accuracy}%</span>
                  </div>
                  <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${model.isDefault ? 'bg-primary' : 'bg-muted-foreground'}`}
                      style={{ width: `${model.accuracy}%` }}
                    ></div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border/50">
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Parameters</div>
                    <div className="font-mono text-sm">{model.parameters}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Training Data</div>
                    <div className="font-mono text-xs truncate" title={model.trainingDataset}>{model.trainingDataset}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border/50 bg-card/50 backdrop-blur mt-8">
        <CardHeader>
          <CardTitle>Architecture: Hybrid Fusion V2</CardTitle>
          <CardDescription>Topological visualization of the active inference model</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-6 bg-background rounded-lg border border-border/50 font-mono text-xs text-muted-foreground overflow-x-auto whitespace-pre">
{`[Audio Input: 16kHz WAV]
       │
       ▼
[Librosa Feature Extraction]
 ├─ MFCCs (13-40)
 ├─ Mel-spectrogram
 ├─ Zero Crossing Rate
 └─ RMS Energy
       │
       ▼
[CNN Spatial Block] ───────┐
 ├─ Conv1D (64 filters)    │ Captures frequency domain
 ├─ MaxPooling1D           │ local spatial features
 ├─ Conv1D (128 filters)   │ (timbre, formants)
 └─ MaxPooling1D           │
       │                   │
       ▼                   │
[LSTM Temporal Block] ─────┤
 ├─ LSTM (128 units)       │ Captures long-term
 ├─ Dropout (0.3)          │ dependencies (prosody,
 └─ LSTM (64 units)        │ rhythm, pacing)
       │                   │
       ▼                   │
[Dense Fusion Layer] <─────┘
 ├─ Dense (128 units)
 ├─ ReLU Activation
 └─ Dense (64 units)
       │
       ▼
[Softmax Classification]
 └─ 8 Emotion Classes probabilities`}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
