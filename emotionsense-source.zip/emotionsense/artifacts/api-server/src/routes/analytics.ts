import { Router, type IRouter } from "express";
import { eq, desc, and, gte, sql } from "drizzle-orm";
import { db, analysisResultsTable } from "@workspace/db";
import { requireAuth, type AuthRequest } from "../middlewares/auth";
import { GetEmotionTrendsQueryParams } from "@workspace/api-zod";

const router: IRouter = Router();

const POSITIVE_EMOTIONS = new Set(["happy", "calm", "surprise"]);
const NEGATIVE_EMOTIONS = new Set(["sad", "angry", "fear", "disgust"]);

router.get("/analytics/dashboard", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.userId!;
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);

  const [{ total }] = await db
    .select({ total: sql<number>`count(*)::int` })
    .from(analysisResultsTable)
    .where(eq(analysisResultsTable.userId, userId));

  const [{ today }] = await db
    .select({ today: sql<number>`count(*)::int` })
    .from(analysisResultsTable)
    .where(and(eq(analysisResultsTable.userId, userId), gte(analysisResultsTable.createdAt, todayStart)));

  const emotionCounts = await db
    .select({
      emotion: analysisResultsTable.dominantEmotion,
      count: sql<number>`count(*)::int`,
    })
    .from(analysisResultsTable)
    .where(eq(analysisResultsTable.userId, userId))
    .groupBy(analysisResultsTable.dominantEmotion)
    .orderBy(desc(sql`count(*)`));

  const mostFrequent = emotionCounts[0]?.emotion ?? "neutral";

  const [{ avgConf }] = await db
    .select({ avgConf: sql<number>`avg(confidence)::float` })
    .from(analysisResultsTable)
    .where(eq(analysisResultsTable.userId, userId));

  const recentRows = await db
    .select()
    .from(analysisResultsTable)
    .where(eq(analysisResultsTable.userId, userId))
    .orderBy(desc(analysisResultsTable.createdAt))
    .limit(5);

  const positiveCount = emotionCounts
    .filter(e => POSITIVE_EMOTIONS.has(e.emotion))
    .reduce((sum, e) => sum + e.count, 0);
  const stabilityScore = total > 0 ? Math.round((positiveCount / total) * 100) : 50;

  const weekAgo = new Date(Date.now() - 7 * 24 * 3600 * 1000);
  const [{ weekCount }] = await db
    .select({ weekCount: sql<number>`count(*)::int` })
    .from(analysisResultsTable)
    .where(and(eq(analysisResultsTable.userId, userId), gte(analysisResultsTable.createdAt, weekAgo)));

  res.json({
    totalAnalyses: total,
    todayAnalyses: today,
    mostFrequentEmotion: mostFrequent,
    averageConfidence: Math.round((avgConf ?? 0.7) * 1000) / 1000,
    stabilityScore,
    weeklyChange: weekCount,
    recentActivity: recentRows.map(r => ({
      id: r.id,
      filename: r.filename,
      dominantEmotion: r.dominantEmotion,
      confidence: r.confidence,
      duration: null,
      emotionScores: r.emotionScores,
      aiInsight: r.aiInsight,
      createdAt: r.createdAt.toISOString(),
    })),
  });
});

router.get("/analytics/trends", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = GetEmotionTrendsQueryParams.safeParse(req.query);
  const period = parsed.success ? (parsed.data.period ?? "weekly") : "weekly";
  const userId = req.userId!;

  let daysBack = period === "daily" ? 1 : period === "weekly" ? 7 : 30;
  const since = new Date(Date.now() - daysBack * 24 * 3600 * 1000);

  const rows = await db
    .select({
      date: sql<string>`date_trunc('day', created_at)::date::text`,
      emotion: analysisResultsTable.dominantEmotion,
      count: sql<number>`count(*)::int`,
    })
    .from(analysisResultsTable)
    .where(and(eq(analysisResultsTable.userId, userId), gte(analysisResultsTable.createdAt, since)))
    .groupBy(sql`date_trunc('day', created_at)::date`, analysisResultsTable.dominantEmotion)
    .orderBy(sql`date_trunc('day', created_at)::date`);

  const emotions = ["happy", "sad", "angry", "fear", "neutral", "calm", "surprise", "disgust"];
  const emotionSeries: Record<string, number[]> = {};
  const dateSet = new Set<string>();
  rows.forEach(r => dateSet.add(r.date));
  const dates = Array.from(dateSet).sort();

  for (const e of emotions) {
    emotionSeries[e] = dates.map(d => {
      const found = rows.find(r => r.date === d && r.emotion === e);
      return found ? found.count : 0;
    });
  }

  res.json({
    period,
    data: rows.map(r => ({ date: r.date, emotion: r.emotion, count: r.count })),
    emotionSeries,
  });
});

router.get("/analytics/distribution", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.userId!;

  const [{ total }] = await db
    .select({ total: sql<number>`count(*)::int` })
    .from(analysisResultsTable)
    .where(eq(analysisResultsTable.userId, userId));

  const rows = await db
    .select({
      emotion: analysisResultsTable.dominantEmotion,
      count: sql<number>`count(*)::int`,
    })
    .from(analysisResultsTable)
    .where(eq(analysisResultsTable.userId, userId))
    .groupBy(analysisResultsTable.dominantEmotion)
    .orderBy(desc(sql`count(*)`));

  res.json({
    items: rows.map(r => ({
      emotion: r.emotion,
      count: r.count,
      percentage: total > 0 ? Math.round((r.count / total) * 1000) / 10 : 0,
    })),
    total,
  });
});

router.get("/analytics/stability", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const userId = req.userId!;
  const monthAgo = new Date(Date.now() - 30 * 24 * 3600 * 1000);
  const twoWeeksAgo = new Date(Date.now() - 14 * 24 * 3600 * 1000);
  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 3600 * 1000);

  const rows = await db
    .select({
      emotion: analysisResultsTable.dominantEmotion,
      count: sql<number>`count(*)::int`,
    })
    .from(analysisResultsTable)
    .where(and(eq(analysisResultsTable.userId, userId), gte(analysisResultsTable.createdAt, monthAgo)))
    .groupBy(analysisResultsTable.dominantEmotion);

  const total = rows.reduce((s, r) => s + r.count, 0);
  const positiveCount = rows.filter(r => POSITIVE_EMOTIONS.has(r.emotion)).reduce((s, r) => s + r.count, 0);
  const negativeCount = rows.filter(r => NEGATIVE_EMOTIONS.has(r.emotion)).reduce((s, r) => s + r.count, 0);

  const positiveRatio = total > 0 ? positiveCount / total : 0.5;
  const negativeRatio = total > 0 ? negativeCount / total : 0.3;
  const score = Math.round(positiveRatio * 100);

  const [{ prevCount }] = await db
    .select({ prevCount: sql<number>`count(*)::int` })
    .from(analysisResultsTable)
    .where(and(eq(analysisResultsTable.userId, userId), gte(analysisResultsTable.createdAt, twoWeeksAgo)));

  const [{ recentCount }] = await db
    .select({ recentCount: sql<number>`count(*)::int` })
    .from(analysisResultsTable)
    .where(and(eq(analysisResultsTable.userId, userId), gte(analysisResultsTable.createdAt, oneWeekAgo)));

  const trend = recentCount > prevCount * 0.6 ? "improving" : recentCount < prevCount * 0.4 ? "declining" : "stable";
  const label = score >= 70 ? "Excellent" : score >= 50 ? "Good" : score >= 30 ? "Fair" : "Needs Attention";
  const riskAlert = negativeRatio > 0.6;

  const insights: string[] = [];
  if (positiveRatio > 0.6) insights.push("Your emotional state has been predominantly positive this month.");
  if (negativeRatio > 0.4) insights.push("Elevated negative emotions detected — consider stress-reduction activities.");
  if (trend === "improving") insights.push("Your emotional trend is improving over the past week.");
  if (trend === "declining") insights.push("Emotional patterns show a declining trend — monitor closely.");
  if (total < 5) insights.push("More recordings will improve the accuracy of your insights.");
  if (insights.length === 0) insights.push("Your emotional patterns are within normal ranges.");

  res.json({ score, label, trend, positiveRatio, negativeRatio, riskAlert, insights });
});

export default router;
