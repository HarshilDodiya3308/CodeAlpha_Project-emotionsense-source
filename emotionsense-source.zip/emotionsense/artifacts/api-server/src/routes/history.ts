import { Router, type IRouter } from "express";
import { eq, desc, and, ilike, gte, lte, sql } from "drizzle-orm";
import { db, analysisResultsTable } from "@workspace/db";
import { requireAuth, type AuthRequest } from "../middlewares/auth";
import { ListHistoryQueryParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/history", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = ListHistoryQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { page, limit, emotion, search, startDate, endDate } = parsed.data;
  const offset = ((page ?? 1) - 1) * (limit ?? 20);
  const pageSize = limit ?? 20;

  const conditions = [eq(analysisResultsTable.userId, req.userId!)];

  if (emotion) {
    conditions.push(eq(analysisResultsTable.dominantEmotion, emotion));
  }
  if (search) {
    conditions.push(ilike(analysisResultsTable.filename, `%${search}%`));
  }
  if (startDate) {
    conditions.push(gte(analysisResultsTable.createdAt, new Date(startDate)));
  }
  if (endDate) {
    conditions.push(lte(analysisResultsTable.createdAt, new Date(endDate)));
  }

  const whereClause = and(...conditions);

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(analysisResultsTable)
    .where(whereClause);

  const rows = await db
    .select()
    .from(analysisResultsTable)
    .where(whereClause)
    .orderBy(desc(analysisResultsTable.createdAt))
    .limit(pageSize)
    .offset(offset);

  res.json({
    items: rows.map(r => ({
      id: r.id,
      filename: r.filename,
      dominantEmotion: r.dominantEmotion,
      confidence: r.confidence,
      duration: null,
      emotionScores: r.emotionScores,
      aiInsight: r.aiInsight,
      createdAt: r.createdAt.toISOString(),
    })),
    total: count,
    page: page ?? 1,
    limit: pageSize,
  });
});

export default router;
