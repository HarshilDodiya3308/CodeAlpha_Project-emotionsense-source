import { useGetDashboardSummary, useGetEmotionTrends } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Activity, AlertTriangle, ArrowRight, BarChart3, BrainCircuit, Headphones, Mic, ShieldAlert } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { format } from "date-fns";

const EMOTION_COLORS: Record<string, string> = {
  happy: "var(--emotion-happy)",
  sad: "var(--emotion-sad)",
  angry: "var(--emotion-angry)",
  fear: "var(--emotion-fear)",
  neutral: "var(--emotion-neutral)",
  calm: "var(--emotion-calm)",
  surprise: "var(--emotion-surprise)",
  disgust: "var(--emotion-disgust)",
};

export default function Dashboard() {
  const { data: summary, isLoading: isSummaryLoading } = useGetDashboardSummary();
  const { data: trends, isLoading: isTrendsLoading } = useGetEmotionTrends({ period: 'weekly' });

  if (isSummaryLoading || isTrendsLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Skeleton className="lg:col-span-2 h-[400px] rounded-xl" />
          <Skeleton className="h-[400px] rounded-xl" />
        </div>
      </div>
    );
  }

  const chartData = trends?.data || [];
  
  // Create pie chart data from summary if needed, or mock it since we don't have distribution endpoint in this scope directly
  const recentEmotions = summary?.recentActivity.reduce((acc, curr) => {
    acc[curr.dominantEmotion] = (acc[curr.dominantEmotion] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  const pieData = Object.entries(recentEmotions || {}).map(([name, value]) => ({
    name,
    value
  }));

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Signal Overview</h1>
          <p className="text-muted-foreground">Real-time emotional intelligence telemetry</p>
        </div>
        <Link href="/analyze">
          <Button className="gap-2 shadow-lg hover:shadow-primary/25 transition-all">
            <Mic className="h-4 w-4" /> New Analysis
          </Button>
        </Link>
      </div>

      {summary?.stabilityScore && summary.stabilityScore < 60 && (
        <Alert variant="destructive" className="bg-destructive/10 border-destructive/20 text-destructive-foreground">
          <ShieldAlert className="h-4 w-4" />
          <AlertTitle>Low Stability Detected</AlertTitle>
          <AlertDescription>
            The aggregate emotional stability score has dropped below 60%. Review recent high-variance recordings.
          </AlertDescription>
        </Alert>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-border/50 bg-card/50 backdrop-blur">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Analyses</CardTitle>
            <Headphones className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary?.totalAnalyses.toLocaleString() || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">
              <span className="text-primary">+{summary?.todayAnalyses || 0}</span> today
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50 backdrop-blur">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Dominant Vector</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold capitalize flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: EMOTION_COLORS[summary?.mostFrequentEmotion || 'neutral'] }}></div>
              {summary?.mostFrequentEmotion || 'N/A'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Primary emotional signature
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50 backdrop-blur">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Model Confidence</CardTitle>
            <BrainCircuit className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{(summary?.averageConfidence || 0).toFixed(1)}%</div>
            <div className="w-full bg-secondary h-1.5 rounded-full mt-2 overflow-hidden">
              <div 
                className="bg-primary h-full rounded-full" 
                style={{ width: `${summary?.averageConfidence || 0}%` }}
              ></div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50 backdrop-blur">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Stability Score</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary?.stabilityScore || 0}/100</div>
            <p className="text-xs text-muted-foreground mt-1">
              {summary?.weeklyChange && summary.weeklyChange > 0 ? (
                <span className="text-emerald-500">+{summary.weeklyChange}%</span>
              ) : (
                <span className="text-destructive">{summary?.weeklyChange || 0}%</span>
              )} from last week
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trend Chart */}
        <Card className="lg:col-span-2 border-border/50 bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle>Temporal Emotion Signatures</CardTitle>
            <CardDescription>7-day rolling frequency of dominant emotions</CardDescription>
          </CardHeader>
          <CardContent className="h-[350px]">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12} 
                    tickFormatter={(val) => format(new Date(val), 'MMM dd')}
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                    labelStyle={{ color: 'hsl(var(--muted-foreground))' }}
                  />
                  <Legend />
                  {Object.keys(EMOTION_COLORS).map(emotion => (
                    <Line 
                      key={emotion}
                      type="monotone" 
                      dataKey={emotion} 
                      stroke={EMOTION_COLORS[emotion]} 
                      strokeWidth={2}
                      dot={false}
                      activeDot={{ r: 6 }}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                Insufficient temporal data
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="border-border/50 bg-card/50 backdrop-blur flex flex-col">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle>Recent Telemetry</CardTitle>
              <Link href="/history">
                <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs">
                  View All <ArrowRight className="h-3 w-3" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="flex-1 overflow-auto">
            <div className="space-y-4">
              {summary?.recentActivity && summary.recentActivity.length > 0 ? (
                summary.recentActivity.slice(0, 5).map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50">
                    <div className="flex items-center gap-3 overflow-hidden">
                      <div 
                        className="w-2 h-10 rounded-full shrink-0" 
                        style={{ backgroundColor: EMOTION_COLORS[item.dominantEmotion] }}
                      ></div>
                      <div className="truncate">
                        <div className="font-medium text-sm truncate">{item.filename}</div>
                        <div className="text-xs text-muted-foreground flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-[10px] h-4 px-1" style={{ color: EMOTION_COLORS[item.dominantEmotion], borderColor: EMOTION_COLORS[item.dominantEmotion] }}>
                            {item.dominantEmotion}
                          </Badge>
                          <span>{format(new Date(item.createdAt), 'HH:mm')}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-sm font-medium">{item.confidence.toFixed(1)}%</div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Conf</div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  No recent activity logged.
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
