import { pgTable, serial, integer, text, real, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const analysisResultsTable = pgTable("analysis_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  audioFileId: integer("audio_file_id"),
  filename: text("filename").notNull(),
  dominantEmotion: text("dominant_emotion").notNull(),
  confidence: real("confidence").notNull(),
  emotionScores: jsonb("emotion_scores").notNull(),
  modelUsed: text("model_used").notNull().default("CNN_LSTM"),
  processingTime: real("processing_time").notNull().default(0),
  features: jsonb("features"),
  aiInsight: text("ai_insight"),
  riskAlert: boolean("risk_alert").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAnalysisResultSchema = createInsertSchema(analysisResultsTable).omit({ id: true, createdAt: true });
export type InsertAnalysisResult = z.infer<typeof insertAnalysisResultSchema>;
export type AnalysisResult = typeof analysisResultsTable.$inferSelect;
