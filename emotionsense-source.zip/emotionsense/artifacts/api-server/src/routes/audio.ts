import { Router, type IRouter } from "express";
import { eq, and, desc, ilike, sql } from "drizzle-orm";
import { db, audioFilesTable, analysisResultsTable } from "@workspace/db";
import { requireAuth, type AuthRequest } from "../middlewares/auth";
import { ListAudioFilesQueryParams, GetAudioFileParams, DeleteAudioFileParams } from "@workspace/api-zod";
import fs from "fs";

const router: IRouter = Router();

router.get("/audio", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = ListAudioFilesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { page, limit, search } = parsed.data;
  const offset = ((page ?? 1) - 1) * (limit ?? 20);
  const pageSize = limit ?? 20;

  const conditions = [eq(audioFilesTable.userId, req.userId!)];
  if (search) {
    conditions.push(ilike(audioFilesTable.originalName, `%${search}%`));
  }
  const whereClause = and(...conditions);

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(audioFilesTable)
    .where(whereClause);

  const rows = await db
    .select()
    .from(audioFilesTable)
    .where(whereClause)
    .orderBy(desc(audioFilesTable.createdAt))
    .limit(pageSize)
    .offset(offset);

  const items = await Promise.all(rows.map(async (af) => {
    const [analysis] = await db
      .select()
      .from(analysisResultsTable)
      .where(eq(analysisResultsTable.audioFileId, af.id))
      .orderBy(desc(analysisResultsTable.createdAt))
      .limit(1);

    return {
      id: af.id,
      filename: af.filename,
      originalName: af.originalName,
      duration: af.duration,
      fileSize: af.fileSize,
      format: af.format,
      createdAt: af.createdAt.toISOString(),
      analysisResult: analysis ? {
        id: analysis.id,
        audioFileId: analysis.audioFileId,
        dominantEmotion: analysis.dominantEmotion,
        confidence: analysis.confidence,
        emotionScores: analysis.emotionScores,
        modelUsed: analysis.modelUsed,
        processingTime: analysis.processingTime,
        features: analysis.features,
        aiInsight: analysis.aiInsight,
        riskAlert: analysis.riskAlert,
        createdAt: analysis.createdAt.toISOString(),
      } : undefined,
    };
  }));

  res.json({ items, total: count, page: page ?? 1, limit: pageSize });
});

router.get("/audio/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetAudioFileParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const [af] = await db
    .select()
    .from(audioFilesTable)
    .where(and(eq(audioFilesTable.id, params.data.id), eq(audioFilesTable.userId, req.userId!)));

  if (!af) {
    res.status(404).json({ error: "Audio file not found" });
    return;
  }

  const [analysis] = await db
    .select()
    .from(analysisResultsTable)
    .where(eq(analysisResultsTable.audioFileId, af.id))
    .orderBy(desc(analysisResultsTable.createdAt))
    .limit(1);

  res.json({
    id: af.id,
    filename: af.filename,
    originalName: af.originalName,
    duration: af.duration,
    fileSize: af.fileSize,
    format: af.format,
    createdAt: af.createdAt.toISOString(),
    analysisResult: analysis ? {
      id: analysis.id,
      audioFileId: analysis.audioFileId,
      dominantEmotion: analysis.dominantEmotion,
      confidence: analysis.confidence,
      emotionScores: analysis.emotionScores,
      modelUsed: analysis.modelUsed,
      processingTime: analysis.processingTime,
      features: analysis.features,
      aiInsight: analysis.aiInsight,
      riskAlert: analysis.riskAlert,
      createdAt: analysis.createdAt.toISOString(),
    } : undefined,
  });
});

router.delete("/audio/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = DeleteAudioFileParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const [af] = await db
    .select()
    .from(audioFilesTable)
    .where(and(eq(audioFilesTable.id, params.data.id), eq(audioFilesTable.userId, req.userId!)));

  if (!af) {
    res.status(404).json({ error: "Audio file not found" });
    return;
  }

  if (fs.existsSync(af.filePath)) {
    fs.unlinkSync(af.filePath);
  }

  await db.delete(audioFilesTable).where(eq(audioFilesTable.id, af.id));

  res.json({ success: true, message: "Audio file deleted" });
});

export default router;
