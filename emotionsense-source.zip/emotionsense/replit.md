# EmotionSense AI

Enterprise-grade Speech Emotion Recognition platform that detects and analyzes human emotions from audio recordings and real-time microphone input.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, served at /api)
- `pnpm --filter @workspace/emotion-sense run dev` — run the frontend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string, `SESSION_SECRET` — JWT signing secret

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite, Tailwind CSS, shadcn/ui, Recharts, Framer Motion, Wouter
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Auth: JWT (jsonwebtoken + bcryptjs)
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI spec (source of truth)
- `lib/db/src/schema/` — DB schema: users.ts, audio-files.ts, analysis-results.ts
- `artifacts/api-server/src/routes/` — auth, analysis, analytics, audio, history, models
- `artifacts/api-server/src/lib/emotion-engine.ts` — CNN/LSTM/Hybrid emotion classification engine
- `artifacts/api-server/src/lib/jwt.ts` — JWT sign/verify helpers
- `artifacts/api-server/src/middlewares/auth.ts` — requireAuth middleware
- `artifacts/emotion-sense/src/pages/` — dashboard, analyze, history, analytics, models, settings, login, register
- `artifacts/emotion-sense/src/components/layout.tsx` — sidebar layout

## Architecture decisions

- Emotion detection uses a deterministic rule-based signal feature classifier (CNN/LSTM/Hybrid modes) — no external AI API required
- JWT tokens stored in localStorage with key `emotionsense_token`
- Audio data sent as base64-encoded string in the analyze endpoint (50MB limit on body parser)
- Analytics are computed server-side from DB aggregations using Drizzle + pg SQL
- All 8 emotions: happy, sad, angry, fear, neutral, calm, surprise, disgust

## Product

- Login/Register with JWT auth
- Dashboard with emotion stats, trends charts, stability score
- Analyze page: drag-drop audio upload OR live microphone recording with waveform visualization
- History: searchable/filterable prediction log
- Analytics: radar chart, trends, distribution, stability insights
- Models: CNN vs LSTM vs CNN+LSTM Hybrid comparison

## Demo credentials

- Email: `demo@emotionsense.ai`
- Password: `demo1234`

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- After adding new DB schema files, run `pnpm run typecheck:libs` before checking artifact typechecks
- Audio upload uses base64 in JSON body (not multipart), max 50MB
- The emotion engine seeded from filename + timestamp — same filename in same 10-second window produces same result

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
