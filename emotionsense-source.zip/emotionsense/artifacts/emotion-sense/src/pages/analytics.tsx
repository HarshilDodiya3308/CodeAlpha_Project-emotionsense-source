import { useState } from "react";
import { useGetEmotionTrends, useGetEmotionDistribution, useGetStabilityScore } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

const EMOTION_COLORS: Record<string, string> = {
  happy:    "#22c55e",
  sad:      "#3b82f6",
  angry:    "#ef4444",
  fear:     "#a855f7",
  neutral:  "#94a3b8",
  calm:     "#06b6d4",
  surprise: "#f59e0b",
  disgust:  "#84cc16",
};

const EMOTIONS = ["happy", "sad", "angry", "fear", "neutral", "calm", "surprise", "disgust"];

export default function Analytics() {
  const [period, setPeriod] = useState<"daily" | "weekly" | "monthly">("weekly");

  const { data: trends, isLoading: isTrendsLoading } = useGetEmotionTrends({ period });
  const { data: distribution, isLoading: isDistLoading } = useGetEmotionDistribution();
  const { data: stability, isLoading: isStabilityLoading } = useGetStabilityScore();

  // Radar chart: one point per emotion with percentage value
  const radarData = EMOTIONS.map((emotion) => {
    const found = distribution?.items?.find((d: any) => d.emotion === emotion);
    return { emotion, value: found ? found.percentage : 0 };
  });

  // Pivot trends data: [{date, emotion, count}] → [{date, happy:N, sad:N, ...}]
  const pivotedBarData = (() => {
    const rows = trends?.data ?? [];
    const map = new Map<string, Record<string, number>>();
    for (const row of rows) {
      if (!map.has(row.date)) map.set(row.date, { date: row.date as unknown as number });
      map.get(row.date)![row.emotion] = row.count;
    }
    return Array.from(map.values()).sort((a, b) =>
      String(a.date).localeCompare(String(b.date))
    );
  })();

  const stabilityScore = stability?.score ?? 0;
  const stabilityLabel = stability?.label ?? "—";
  const positiveRatio = Math.round((stability?.positiveRatio ?? 0) * 100);
  const negativeRatio = Math.round((stability?.negativeRatio ?? 0) * 100);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Macro Analytics</h1>
          <p className="text-muted-foreground">High-level semantic distribution and stability metrics</p>
        </div>

        <Select value={period} onValueChange={(val: any) => setPeriod(val)}>
          <SelectTrigger className="w-[180px] bg-card/50 backdrop-blur border-border/50">
            <SelectValue placeholder="Select period" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="daily">Daily Resolution</SelectItem>
            <SelectItem value="weekly">Weekly Resolution</SelectItem>
            <SelectItem value="monthly">Monthly Resolution</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Radar Chart — real distribution data */}
        <Card className="border-border/50 bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-sm text-muted-foreground font-medium uppercase tracking-wider">Acoustic Vector Balance</CardTitle>
            <CardDescription>Multi-dimensional emotional distribution footprint</CardDescription>
          </CardHeader>
          <CardContent className="h-[350px]">
            {isDistLoading ? (
              <Skeleton className="w-full h-full rounded-full" />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                  <PolarGrid stroke="hsl(var(--border))" />
                  <PolarAngleAxis
                    dataKey="emotion"
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                  />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar
                    name="% of total"
                    dataKey="value"
                    stroke="hsl(var(--primary))"
                    fill="hsl(var(--primary))"
                    fillOpacity={0.3}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))", borderRadius: "8px" }}
                    formatter={(val: number) => [`${val}%`, "Share"]}
                  />
                </RadarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Stability Score Card */}
        <Card className="border-border/50 bg-card/50 backdrop-blur flex flex-col justify-between overflow-hidden relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 blur-[100px] -z-10"></div>
          <CardHeader>
            <CardTitle className="text-sm text-muted-foreground font-medium uppercase tracking-wider">System Stability Index</CardTitle>
            <CardDescription>{stability?.insights?.[0] ?? "30-day emotional stability score"}</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col items-center justify-center">
            {isStabilityLoading ? (
              <Skeleton className="w-32 h-32 rounded-full" />
            ) : (
              <>
                <div className="relative flex items-center justify-center w-40 h-40 mb-6">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle cx="80" cy="80" r="70" stroke="hsl(var(--secondary))" strokeWidth="8" fill="none" />
                    <circle
                      cx="80" cy="80" r="70"
                      stroke="hsl(var(--primary))"
                      strokeWidth="8" fill="none"
                      strokeDasharray="439.8"
                      strokeDashoffset={439.8 - (439.8 * stabilityScore) / 100}
                      className="transition-all duration-1000 ease-out"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-4xl font-light tracking-tighter">{stabilityScore}</span>
                    <span className="text-[10px] uppercase tracking-widest text-muted-foreground">{stabilityLabel}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 w-full gap-4 pt-4 border-t border-border/50">
                  <div className="text-center">
                    <div className="text-sm font-medium text-emerald-500 mb-1">{positiveRatio}%</div>
                    <div className="text-xs text-muted-foreground">Positive Sentiment</div>
                  </div>
                  <div className="text-center border-l border-border/50">
                    <div className="text-sm font-medium text-destructive mb-1">{negativeRatio}%</div>
                    <div className="text-xs text-muted-foreground">Negative Sentiment</div>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Stacked Bar Chart — pivoted trend data */}
        <Card className="md:col-span-2 border-border/50 bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-sm text-muted-foreground font-medium uppercase tracking-wider">Temporal Volume Analysis</CardTitle>
            <CardDescription>Absolute count of emotion vectors over the active period</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px]">
            {isTrendsLoading ? (
              <Skeleton className="w-full h-full" />
            ) : pivotedBarData.length === 0 ? (
              <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                No trend data for this period yet.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={pivotedBarData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis
                    dataKey="date"
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    tickFormatter={(val) => {
                      const d = new Date(val);
                      return period === "daily"
                        ? `${d.getHours()}:00`
                        : `${d.getMonth() + 1}/${d.getDate()}`;
                    }}
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))", borderRadius: "8px" }}
                    labelStyle={{ color: "hsl(var(--muted-foreground))", marginBottom: "8px" }}
                    cursor={{ fill: "hsl(var(--muted)/0.5)" }}
                  />
                  <Legend />
                  {EMOTIONS.map((emotion, idx) => (
                    <Bar
                      key={emotion}
                      dataKey={emotion}
                      stackId="a"
                      fill={EMOTION_COLORS[emotion]}
                      radius={idx === EMOTIONS.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]}
                    />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
