import bcrypt from "bcryptjs";
import { db, usersTable, analysisResultsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const DEMO_EMAIL = "demo@emotionsense.ai";
const DEMO_PASSWORD = "demo1234";
const DEMO_NAME = "Alex Chen";

const FILENAMES = [
  "speech_test.wav",
  "meeting_recording.wav",
  "interview.mp3",
  "focus_group.wav",
  "customer_call.wav",
  "team_standup.wav",
  "presentation.wav",
  "lecture_clip.wav",
];

const EMOTIONS = ["happy", "sad", "angry", "fear", "neutral", "calm", "surprise", "disgust"] as const;
type Emotion = typeof EMOTIONS[number];

const INSIGHTS: Record<Emotion, string> = {
  happy:    "Elevated pitch and rhythmic cadence indicate positive arousal.",
  sad:      "Low energy and falling intonation patterns suggest subdued affect.",
  angry:    "Aggressive speech patterns with sharp energy bursts detected.",
  fear:     "Trembling vocal quality and irregular cadence suggest anxiety or fear.",
  neutral:  "Flat prosody and steady energy levels indicate a neutral baseline.",
  calm:     "Smooth prosody and regular cadence suggest a relaxed state.",
  surprise: "Sudden pitch peaks and increased tempo indicate surprise.",
  disgust:  "Low-frequency growl components and harsh spectral texture detected.",
};

function buildScores(dominant: Emotion, confidence: number) {
  const remaining = 1 - confidence;
  const others = EMOTIONS.filter((e) => e !== dominant);
  let leftover = remaining;
  return EMOTIONS.map((emotion, i) => {
    if (emotion === dominant) return { emotion, confidence };
    const isLast = i === EMOTIONS.length - 1 || (EMOTIONS[i + 1] === dominant && i === EMOTIONS.length - 2);
    const share = isLast ? parseFloat(leftover.toFixed(2)) : parseFloat((remaining / others.length).toFixed(2));
    leftover = parseFloat((leftover - share).toFixed(2));
    return { emotion, confidence: share };
  });
}

function pickEmotion(seed: number): { emotion: Emotion; confidence: number } {
  const idx = seed % EMOTIONS.length;
  const emotion = EMOTIONS[idx];
  const confidence = parseFloat((0.55 + (seed % 40) / 100).toFixed(2));
  return { emotion, confidence };
}

async function main() {
  console.log("🌱 Seeding database...");

  // Upsert demo user
  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, DEMO_EMAIL));
  let userId: number;

  if (existing.length > 0) {
    await db.update(usersTable).set({ passwordHash }).where(eq(usersTable.email, DEMO_EMAIL));
    userId = existing[0].id;
    console.log(`✓ Updated demo user (id=${userId})`);
  } else {
    const [user] = await db
      .insert(usersTable)
      .values({ email: DEMO_EMAIL, name: DEMO_NAME, passwordHash, role: "user" })
      .returning();
    userId = user.id;
    console.log(`✓ Created demo user (id=${userId})`);
  }

  // Seed 62 analysis records spread over the last 30 days
  const existingCount = await db
    .select()
    .from(analysisResultsTable)
    .then((r) => r.filter((x) => x.userId === userId).length);

  if (existingCount >= 62) {
    console.log(`✓ Analysis records already seeded (${existingCount} found)`);
  } else {
    console.log(`Seeding analysis records (found ${existingCount}, need 62)...`);
    const now = Date.now();
    const records = Array.from({ length: 62 }, (_, i) => {
      const hoursAgo = i * 12;
      const createdAt = new Date(now - hoursAgo * 60 * 60 * 1000);
      const seed = (i * 7 + 13) % 100;
      const { emotion, confidence } = pickEmotion(seed);
      const filename = FILENAMES[i % FILENAMES.length];
      return {
        userId,
        filename,
        dominantEmotion: emotion,
        confidence,
        emotionScores: buildScores(emotion, confidence),
        modelUsed: i % 3 === 0 ? "CNN" : i % 3 === 1 ? "LSTM" : "CNN_LSTM",
        processingTime: parseFloat((0.1 + (seed % 20) / 100).toFixed(3)),
        aiInsight: INSIGHTS[emotion],
        riskAlert: emotion === "angry" || emotion === "fear",
        createdAt,
      };
    });

    // Clear existing for this user and re-insert
    await db.delete(analysisResultsTable).where(eq(analysisResultsTable.userId, userId));
    await db.insert(analysisResultsTable).values(records);
    console.log(`✓ Seeded 62 analysis records`);
  }

  console.log("✅ Seed complete");
  process.exit(0);
}

main().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
