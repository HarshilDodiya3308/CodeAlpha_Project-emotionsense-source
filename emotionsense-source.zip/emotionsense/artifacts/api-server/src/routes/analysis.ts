import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, analysisResultsTable, audioFilesTable } from "@workspace/db";
import { requireAuth, type AuthRequest } from "../middlewares/auth";
import { analyzeAudio, type AudioFeatures } from "../lib/emotion-engine";
import { AnalyzeAudioBody, GetAnalysisResultParams } from "@workspace/api-zod";
import path from "path";
import fs from "fs";

const router: IRouter = Router();

const workspaceRoot = process.cwd().endsWith(path.join("artifacts", "api-server"))
  ? path.resolve(process.cwd(), "../..")
  : process.cwd();

const uploadsDir = path.resolve(workspaceRoot, "artifacts/api-server/uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

router.post("/analysis/analyze", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = AnalyzeAudioBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { audioData, filename, duration, features } = parsed.data;

  let savedFilename = filename;
  let audioFileId: number | undefined;

  if (audioData) {
    const buffer = Buffer.from(audioData, "base64");
    const ext = filename.split(".").pop() ?? "wav";
    savedFilename = `${Date.now()}_${req.userId}_${filename}`;
    const filePath = path.join(uploadsDir, savedFilename);
    fs.writeFileSync(filePath, buffer);

    const [af] = await db.insert(audioFilesTable).values({
      userId: req.userId!,
      filename: savedFilename,
      originalName: filename,
      filePath,
      duration: duration ?? 0,
      fileSize: buffer.length,
      format: ext,
    }).returning();
    audioFileId = af.id;
  }

  const audioFeatures: AudioFeatures = features ?? {};
  const result = analyzeAudio(audioFeatures, savedFilename, "CNN_LSTM");

  const [saved] = await db.insert(analysisResultsTable).values({
    userId: req.userId!,
    audioFileId: audioFileId ?? null,
    filename: filename,
    dominantEmotion: result.dominantEmotion,
    confidence: result.confidence,
    emotionScores: result.emotionScores,
    modelUsed: result.modelUsed,
    processingTime: result.processingTime,
    features: result.features,
    aiInsight: result.aiInsight,
    riskAlert: result.riskAlert,
  }).returning();

  res.json({
    id: saved.id,
    audioFileId: saved.audioFileId,
    dominantEmotion: saved.dominantEmotion,
    confidence: saved.confidence,
    emotionScores: saved.emotionScores,
    modelUsed: saved.modelUsed,
    processingTime: saved.processingTime,
    features: saved.features,
    aiInsight: saved.aiInsight,
    riskAlert: saved.riskAlert,
    createdAt: saved.createdAt.toISOString(),
  });
});

router.get("/analysis/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetAnalysisResultParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const [result] = await db
    .select()
    .from(analysisResultsTable)
    .where(and(eq(analysisResultsTable.id, params.data.id), eq(analysisResultsTable.userId, req.userId!)));

  if (!result) {
    res.status(404).json({ error: "Analysis result not found" });
    return;
  }

  res.json({
    id: result.id,
    audioFileId: result.audioFileId,
    dominantEmotion: result.dominantEmotion,
    confidence: result.confidence,
    emotionScores: result.emotionScores,
    modelUsed: result.modelUsed,
    processingTime: result.processingTime,
    features: result.features,
    aiInsight: result.aiInsight,
    riskAlert: result.riskAlert,
    createdAt: result.createdAt.toISOString(),
  });
});

export default router;
