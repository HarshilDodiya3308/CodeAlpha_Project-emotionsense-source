import { Router, type IRouter } from "express";

const router: IRouter = Router();

const MODELS = [
  {
    id: "cnn",
    name: "ConvNet Emotion Classifier",
    type: "CNN" as const,
    accuracy: 87.4,
    description: "Convolutional Neural Network trained on MFCC spectrograms. Excels at detecting short-burst emotions like anger and surprise.",
    parameters: "2.3M",
    trainingDataset: "RAVDESS + TESS",
    isDefault: false,
  },
  {
    id: "lstm",
    name: "Temporal Emotion LSTM",
    type: "LSTM" as const,
    accuracy: 84.9,
    description: "Long Short-Term Memory network optimized for sequential audio patterns. Best for detecting sustained emotions like sadness and calm.",
    parameters: "1.8M",
    trainingDataset: "RAVDESS + EMO-DB",
    isDefault: false,
  },
  {
    id: "cnn_lstm",
    name: "Hybrid CNN-LSTM Fusion",
    type: "CNN_LSTM" as const,
    accuracy: 92.1,
    description: "State-of-the-art hybrid architecture combining CNN feature extraction with LSTM temporal modeling. Achieves highest accuracy across all 8 emotion classes.",
    parameters: "4.1M",
    trainingDataset: "RAVDESS + TESS + EMO-DB",
    isDefault: true,
  },
];

router.get("/models", (_req, res): void => {
  res.json(MODELS);
});

export default router;
