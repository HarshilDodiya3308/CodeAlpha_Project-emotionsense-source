import { useState, useRef, useCallback } from "react";
import { useAnalyzeAudio } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mic, UploadCloud, Square, AlertTriangle, Cpu, Clock, Activity, AudioLines, ShieldAlert } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

const EMOTION_COLORS: Record<string, string> = {
  happy:   "#22c55e",
  sad:     "#3b82f6",
  angry:   "#ef4444",
  fear:    "#a855f7",
  neutral: "#94a3b8",
  calm:    "#06b6d4",
  surprise:"#f59e0b",
  disgust: "#84cc16",
};

// ---------------------------------------------------------------------------
// Real audio feature extraction using Web Audio API
// ---------------------------------------------------------------------------

interface AudioFeatures {
  rmsEnergy: number;
  zeroCrossingRate: number;
  spectralCentroid: number;
  spectralRolloff: number;
  tempo: number;
  mfcc: number[];
  chroma: number[];
}

async function extractAudioFeatures(audioBuffer: AudioBuffer): Promise<AudioFeatures> {
  const channelData = audioBuffer.getChannelData(0);
  const sampleRate = audioBuffer.sampleRate;
  const n = channelData.length;

  // --- RMS Energy ---
  let sumSq = 0;
  for (let i = 0; i < n; i++) sumSq += channelData[i] ** 2;
  const rmsEnergy = Math.sqrt(sumSq / n);

  // --- Zero Crossing Rate ---
  let zcr = 0;
  for (let i = 1; i < n; i++) {
    if ((channelData[i] >= 0) !== (channelData[i - 1] >= 0)) zcr++;
  }
  const zeroCrossingRate = zcr / (n - 1);

  // --- FFT for spectral features ---
  // Use OfflineAudioContext analyser to get frequency data
  const fftSize = 2048;
  const nyquist = sampleRate / 2;
  const binCount = fftSize / 2;

  // Compute power spectrum via manual DFT on a window (faster: use sample of frames)
  const frameSize = Math.min(fftSize, n);
  const frame = channelData.slice(0, frameSize);

  // Apply Hann window
  const windowed = new Float32Array(frameSize);
  for (let i = 0; i < frameSize; i++) {
    windowed[i] = frame[i] * (0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (frameSize - 1)));
  }

  // Real DFT (simplified — compute power spectrum for first binCount bins)
  const powerSpectrum = new Float32Array(binCount);
  for (let k = 0; k < binCount; k++) {
    let re = 0, im = 0;
    for (let t = 0; t < frameSize; t++) {
      const angle = (2 * Math.PI * k * t) / frameSize;
      re += windowed[t] * Math.cos(angle);
      im -= windowed[t] * Math.sin(angle);
    }
    powerSpectrum[k] = re * re + im * im;
  }

  const totalPower = powerSpectrum.reduce((a, b) => a + b, 1e-10);

  // Spectral centroid
  let weightedSum = 0;
  for (let k = 0; k < binCount; k++) {
    const freq = (k * nyquist) / binCount;
    weightedSum += freq * powerSpectrum[k];
  }
  const spectralCentroid = weightedSum / totalPower;

  // Spectral rolloff (85th percentile of cumulative energy)
  const threshold = totalPower * 0.85;
  let cumulative = 0;
  let rolloffBin = binCount - 1;
  for (let k = 0; k < binCount; k++) {
    cumulative += powerSpectrum[k];
    if (cumulative >= threshold) { rolloffBin = k; break; }
  }
  const spectralRolloff = (rolloffBin * nyquist) / binCount;

  // --- Tempo estimation (simplified onset detection) ---
  const hopSize = 512;
  const frameCount = Math.floor(n / hopSize);
  const energyFrames: number[] = [];
  for (let f = 0; f < frameCount; f++) {
    let e = 0;
    for (let i = f * hopSize; i < Math.min((f + 1) * hopSize, n); i++) {
      e += channelData[i] ** 2;
    }
    energyFrames.push(e);
  }
  // Count onset-like peaks (energy jumps)
  let onsets = 0;
  const meanEnergy = energyFrames.reduce((a, b) => a + b, 0) / energyFrames.length;
  for (let f = 1; f < energyFrames.length; f++) {
    if (energyFrames[f] > energyFrames[f - 1] * 1.5 && energyFrames[f] > meanEnergy) onsets++;
  }
  const duration = n / sampleRate;
  const tempo = duration > 0 ? Math.max(40, Math.min(240, (onsets / duration) * 30)) : 120;

  // --- Simplified MFCC (13 coefficients using mel filterbank approximation) ---
  const numMfcc = 13;
  const mfcc: number[] = [];
  const numFilters = 26;
  for (let m = 0; m < numMfcc; m++) {
    let coeff = 0;
    for (let f = 0; f < numFilters; f++) {
      const startBin = Math.floor((f * binCount) / numFilters);
      const endBin = Math.floor(((f + 1) * binCount) / numFilters);
      let filterEnergy = 0;
      for (let k = startBin; k < endBin && k < binCount; k++) {
        filterEnergy += powerSpectrum[k];
      }
      const logEnergy = Math.log(filterEnergy + 1e-10);
      coeff += logEnergy * Math.cos((Math.PI * m * (f + 0.5)) / numFilters);
    }
    mfcc.push(coeff);
  }

  // --- Chroma features (12 pitch classes from power spectrum) ---
  const chroma = new Array(12).fill(0);
  for (let k = 1; k < binCount; k++) {
    const freq = (k * nyquist) / binCount;
    if (freq < 50 || freq > 4000) continue;
    const pitch = 12 * Math.log2(freq / 440) % 12;
    const pitchClass = ((Math.round(pitch) % 12) + 12) % 12;
    chroma[pitchClass] += powerSpectrum[k];
  }
  const chromaMax = Math.max(...chroma, 1e-10);
  const normalizedChroma = chroma.map((v) => v / chromaMax);

  return {
    rmsEnergy: Math.min(1, rmsEnergy * 10),
    zeroCrossingRate: Math.min(1, zeroCrossingRate * 10),
    spectralCentroid,
    spectralRolloff,
    tempo,
    mfcc,
    chroma: normalizedChroma,
  };
}

async function decodeAudioFromBase64(base64: string, mimeType: string): Promise<AudioBuffer | null> {
  try {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const audioCtx = new OfflineAudioContext(1, 44100, 44100);
    return await audioCtx.decodeAudioData(bytes.buffer);
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export default function Analyze() {
  const { toast } = useToast();
  const [isRecording, setIsRecording] = useState(false);
  const [activeModel, setActiveModel] = useState("CNN_LSTM");
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isExtracting, setIsExtracting] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);

  const analyzeMutation = useAnalyzeAudio();

  // Draw live waveform during recording
  const startWaveformDraw = useCallback(() => {
    if (!canvasRef.current || !analyserRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d")!;
    const bufferLength = analyserRef.current.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      animationRef.current = requestAnimationFrame(draw);
      analyserRef.current!.getByteTimeDomainData(dataArray);
      ctx.fillStyle = "hsl(222 47% 10%)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.lineWidth = 2;
      ctx.strokeStyle = "hsl(172 66% 50%)";
      ctx.beginPath();
      const sliceWidth = canvas.width / bufferLength;
      let x = 0;
      for (let i = 0; i < bufferLength; i++) {
        const v = dataArray[i] / 128.0;
        const y = (v * canvas.height) / 2;
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        x += sliceWidth;
      }
      ctx.lineTo(canvas.width, canvas.height / 2);
      ctx.stroke();
    };
    draw();
  }, []);

  const handleStartRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const audioCtx = new AudioContext();
      analyserRef.current = audioCtx.createAnalyser();
      audioCtx.createMediaStreamSource(stream).connect(analyserRef.current);
      analyserRef.current.fftSize = 256;

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingDuration(0);
      setAudioUrl(null);
      analyzeMutation.reset();

      timerRef.current = setInterval(() => setRecordingDuration((p) => p + 1), 1000);
      startWaveformDraw();
    } catch {
      toast({ variant: "destructive", title: "Microphone Access Denied", description: "Allow microphone access to record audio." });
    }
  };

  const handleStopRecording = () => {
    if (!mediaRecorderRef.current || !isRecording) return;
    mediaRecorderRef.current.stop();
    mediaRecorderRef.current.stream.getTracks().forEach((t) => t.stop());
    setIsRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
    if (animationRef.current) cancelAnimationFrame(animationRef.current);

    mediaRecorderRef.current.onstop = async () => {
      const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
      setAudioUrl(URL.createObjectURL(blob));
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = () => {
        const b64 = (reader.result as string).split(",")[1];
        submitAnalysis(b64, "recording.webm", recordingDuration, "audio/webm");
      };
    };
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAudioUrl(URL.createObjectURL(file));
    analyzeMutation.reset();
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = () => {
      const b64 = (reader.result as string).split(",")[1];
      submitAnalysis(b64, file.name, 0, file.type || "audio/wav");
    };
    // Reset the input so re-uploading the same file works
    e.target.value = "";
  };

  const submitAnalysis = async (base64: string, filename: string, duration: number, mimeType: string) => {
    setIsExtracting(true);
    let features: AudioFeatures | undefined;
    try {
      const buffer = await decodeAudioFromBase64(base64, mimeType);
      if (buffer) {
        features = await extractAudioFeatures(buffer);
      }
    } catch {
      // fall through — server will generate synthetic features
    } finally {
      setIsExtracting(false);
    }

    analyzeMutation.mutate({
      data: {
        audioData: base64,
        filename,
        duration,
        features: features ?? undefined,
      },
    });
  };

  const formatTime = (s: number) => `0${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  const isPending = analyzeMutation.isPending || isExtracting;
  const result = analyzeMutation.data;

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Signal Analysis</h1>
        <p className="text-muted-foreground">Real-time emotion extraction from audio signals</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ── Left: Input Controls ── */}
        <div className="lg:col-span-1 space-y-4">
          {/* Model selector */}
          <Card className="border-border/50 bg-card/50 backdrop-blur">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Inference Model</CardTitle>
              <CardDescription>Choose the classification architecture</CardDescription>
            </CardHeader>
            <CardContent>
              <Label className="text-xs text-muted-foreground mb-2 block">Architecture</Label>
              <Select value={activeModel} onValueChange={setActiveModel}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="CNN">CNN — Fast, spectral features</SelectItem>
                  <SelectItem value="LSTM">LSTM — Temporal patterns</SelectItem>
                  <SelectItem value="CNN_LSTM">Hybrid CNN-LSTM — Highest accuracy</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Audio input */}
          <Card className="border-border/50 bg-card/50 backdrop-blur">
            <Tabs defaultValue="record">
              <CardHeader className="pb-3">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="record">Live Capture</TabsTrigger>
                  <TabsTrigger value="upload">File Upload</TabsTrigger>
                </TabsList>
              </CardHeader>
              <CardContent>
                {/* Microphone tab */}
                <TabsContent value="record" className="mt-0 space-y-4">
                  <div className="relative aspect-video bg-muted/30 rounded-xl overflow-hidden border border-border/50 flex flex-col items-center justify-center">
                    {isRecording ? (
                      <canvas ref={canvasRef} width={400} height={200} className="absolute inset-0 w-full h-full" />
                    ) : (
                      <Mic className="h-10 w-10 text-muted-foreground/40 mb-2" />
                    )}
                    <div className="relative z-10 flex flex-col items-center mt-auto mb-4">
                      {isRecording && (
                        <div className="flex items-center gap-2 mb-4 bg-background/80 px-3 py-1 rounded-full text-sm font-medium text-destructive animate-pulse">
                          <div className="w-2 h-2 rounded-full bg-destructive" />
                          {formatTime(recordingDuration)}
                        </div>
                      )}
                      {isRecording ? (
                        <Button size="lg" variant="destructive" className="rounded-full h-14 w-14 shadow-lg animate-pulse" onClick={handleStopRecording}>
                          <Square className="h-5 w-5" />
                        </Button>
                      ) : (
                        <Button size="lg" className="rounded-full h-14 w-14 shadow-lg shadow-primary/25" onClick={handleStartRecording}>
                          <Mic className="h-5 w-5" />
                        </Button>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground text-center">Press the mic button to start recording, stop to analyze</p>
                </TabsContent>

                {/* File upload tab */}
                <TabsContent value="upload" className="mt-0">
                  <label className="flex flex-col items-center justify-center w-full aspect-video rounded-xl border-2 border-dashed border-border/50 hover:border-primary/50 bg-muted/20 hover:bg-muted/40 transition-colors cursor-pointer">
                    <div className="flex flex-col items-center justify-center py-6">
                      <UploadCloud className="w-10 h-10 mb-3 text-muted-foreground" />
                      <p className="mb-1 text-sm font-medium"><span className="text-primary">Click to upload</span> or drag & drop</p>
                      <p className="text-xs text-muted-foreground">WAV, MP3, M4A, OGG, WEBM (max 50 MB)</p>
                    </div>
                    <input type="file" className="hidden" accept="audio/*" onChange={handleFileUpload} />
                  </label>
                </TabsContent>
              </CardContent>
            </Tabs>
          </Card>

          {/* Playback */}
          {audioUrl && (
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardContent className="py-3">
                <p className="text-xs text-muted-foreground mb-2">Recorded / Uploaded Audio</p>
                <audio src={audioUrl} controls className="w-full h-9" />
              </CardContent>
            </Card>
          )}
        </div>

        {/* ── Right: Results ── */}
        <div className="lg:col-span-2">
          {isPending ? (
            <Card className="h-full border-border/50 bg-card/50 backdrop-blur flex flex-col items-center justify-center py-24">
              <div className="relative w-20 h-20 mb-6">
                <div className="absolute inset-0 border-4 border-primary/20 rounded-full" />
                <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin" />
                <Activity className="absolute inset-0 m-auto h-7 w-7 text-primary animate-pulse" />
              </div>
              <h3 className="text-lg font-bold tracking-tight">
                {isExtracting ? "Extracting Audio Features…" : "Running Neural Inference…"}
              </h3>
              <p className="text-muted-foreground mt-1 text-sm text-center max-w-xs">
                {isExtracting
                  ? "Analysing spectral centroid, MFCC, ZCR and chroma vectors"
                  : `Classifying with ${activeModel} model`}
              </p>
            </Card>
          ) : result ? (
            <div className="space-y-4 animate-in slide-in-from-right-4 duration-500">
              {/* Risk alert */}
              {result.riskAlert && (
                <Alert variant="destructive" className="bg-destructive/10 border-destructive/30">
                  <ShieldAlert className="h-4 w-4" />
                  <AlertTitle>High-Intensity Negative Signal Detected</AlertTitle>
                  <AlertDescription>Prolonged negative emotional state — manual review recommended.</AlertDescription>
                </Alert>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Dominant emotion */}
                <Card className="border-border/50 bg-card/50 backdrop-blur overflow-hidden relative">
                  <div className="absolute top-0 right-0 w-40 h-40 blur-[80px] opacity-40 -z-10" style={{ backgroundColor: EMOTION_COLORS[result.dominantEmotion] }} />
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Primary Vector</CardTitle>
                  </CardHeader>
                  <CardContent className="flex flex-col items-center py-6">
                    <Badge
                      className="px-5 py-1.5 text-xl font-bold uppercase tracking-widest mb-4"
                      style={{ backgroundColor: EMOTION_COLORS[result.dominantEmotion], color: "#fff" }}
                    >
                      {result.dominantEmotion}
                    </Badge>
                    <div className="text-5xl font-light tracking-tighter">
                      {(result.confidence * 100).toFixed(1)}
                      <span className="text-xl text-muted-foreground">%</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-2 uppercase tracking-widest">Confidence</div>
                  </CardContent>
                  <CardFooter className="bg-muted/20 border-t border-border/50 py-2 flex justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-1"><Cpu className="h-3 w-3" /> {result.modelUsed}</div>
                    <div className="flex items-center gap-1"><Clock className="h-3 w-3" /> {result.processingTime} ms</div>
                  </CardFooter>
                </Card>

                {/* AI insight */}
                <Card className="border-border/50 bg-card/50 backdrop-blur">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Semantic Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed border-l-2 pl-4 italic" style={{ borderColor: EMOTION_COLORS[result.dominantEmotion] }}>
                      "{result.aiInsight}"
                    </p>
                    {result.riskAlert && (
                      <div className="flex items-start gap-2 mt-4 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-xs text-destructive">
                        <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                        <span>Extended negative-valence speech detected. Consider reviewing context or seeking support.</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Probability distribution */}
                <Card className="border-border/50 bg-card/50 backdrop-blur">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Probability Distribution</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {[...result.emotionScores]
                      .sort((a, b) => b.confidence - a.confidence)
                      .map((score) => {
                        const pct = (score.confidence * 100).toFixed(1);
                        const width = score.confidence * 100;
                        return (
                          <div key={score.emotion} className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span className="capitalize font-medium">{score.emotion}</span>
                              <span className="text-muted-foreground tabular-nums">{pct}%</span>
                            </div>
                            <div className="w-full h-1.5 bg-secondary rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full transition-all duration-700 ease-out"
                                style={{ width: `${width}%`, backgroundColor: EMOTION_COLORS[score.emotion] }}
                              />
                            </div>
                          </div>
                        );
                      })}
                  </CardContent>
                </Card>

                {/* Extracted features */}
                <Card className="border-border/50 bg-card/50 backdrop-blur">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Extracted Audio Features</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-3">
                      {result.features &&
                        Object.entries(result.features as Record<string, unknown>)
                          .filter(([, v]) => typeof v === "number")
                          .map(([key, val]) => (
                            <div key={key} className="bg-muted/30 p-3 rounded-lg border border-border/50">
                              <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1 truncate">
                                {key.replace(/([A-Z])/g, " $1").trim()}
                              </div>
                              <div className="font-mono text-sm font-medium">{(val as number).toFixed(3)}</div>
                            </div>
                          ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : (
            <Card className="h-full border-border/50 bg-card/50 backdrop-blur flex flex-col items-center justify-center py-24 border-dashed">
              <AudioLines className="h-12 w-12 text-muted-foreground/30 mb-4" />
              <h3 className="text-lg font-medium text-muted-foreground">Awaiting Signal</h3>
              <p className="text-sm text-muted-foreground/60 mt-1">Upload a file or record audio to begin analysis</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
